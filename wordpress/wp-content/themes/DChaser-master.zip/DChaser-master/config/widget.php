<?php

return array(
   'search'=>array('title'=>''),
   'recent-comments'=>array('title'=>'最近评论','number'=>3),
   'recent-posts'=>array('title'=>'最近文章','number'=>5)
);