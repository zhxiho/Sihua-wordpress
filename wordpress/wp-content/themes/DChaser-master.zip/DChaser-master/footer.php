    <!-- footer start -->
    <div class="content-wrapper footer-main">
        <div class="content-mid-wrapper" style="background-color:;">
            <div class="footer-list">
                <div id="footer-1" class="footer-1" style="background-color:;">
                    <p class="footer-title">产品</p>
                    <p class="footer-info">资料下载</p>
                    <p class="footer-info">申请试用</p>
                </div>
                <div id="footer-1" class="footer-1" style="background-color:;">
                    <p class="footer-title">合作</p>
                    <p class="footer-info">渠道政策</p>
                    <p class="footer-info">合作申请</p>
                    <p class="footer-info">联系我们</p>
                </div>
                <div id="footer-1" class="footer-1" style="background-color:;">
                    <p class="footer-title">关于</p>
                    <p class="footer-info">了解思华</p>
                    <p class="footer-info">加入我们</p>
                </div>
                <div id="footer-2" class="footer-2" style="background-color:;">
                    <p class="footer-title">联系</p>
                    <p class="footer-info">电话：(021)61421822</p>
                    <p class="footer-info">传真：(021)61421822</p>
                    <p class="footer-info">地址：上海市浦东新区博云路22号</p>
                </div>
                <div id="footer-3" class="footer-3" style="background-color:;">
                    <p class="footer-title"></p>
                    <p class="footer-info"></p>
                </div>
                <div id="footer-4" class="footer-4" style="background-color:;">
                    <p class="footer-title-01">扫一扫，关注思华</p>
                    <img class="footer-pic" src="<?php bloginfo('template_url'); ?>/static/img/img/erweima.png" alt="" />
                </div>
            </div>
        </div>
    </div>
    <div class="footer-address">
    	<div class="Title loop-info" style="background-color:;">
            <p>版权信息代码</p>
        </div>
    </div>
    <!-- footer end -->
<!-- main end -->
</body>
</body>
</html>