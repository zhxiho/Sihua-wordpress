<?php 
 get_header('meta');
 get_header(); 
 ?>
<div class="pj-wrapper" style="background-color:red;">
    <img src="<?php bloginfo('template_url');?>/static/img/img/banner1.png">
    <h1>服务支持</h1>
</div>

<?php get_footer(); ?> 